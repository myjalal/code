#include <unistd.h>

void	ft_putchar (char c);

void	ft_putstr (char *str)
{
	int	count;

	count = 0;
	while (str[count])
	{
		ft_putchar (str[count]);
		count++;
	}
}

void	ft_putchar (char c)
{
	write (1, &c, 1);
}
