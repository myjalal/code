#include <unistd.h>

int	ft_strlen (char *str);
int	check_base (char *base);

void	ft_putnbr_base (int nbr, char *base)
{
	int	len;

	len = ft_strlen (base);
	if (!check_base (base))
		write(1, "", 1);
	else
	{
		if (nbr < 0)
		{
			write(1, "-", 1);
			ft_putnbr_base (- (nbr / len), base);
			ft_putnbr_base (- (nbr % len), base);
		}
		else
		{
			if (nbr > ft_strlen (base) - 1)
				ft_putnbr_base (nbr / len, base);
			write (1, &base[nbr % len], 1);
		}
	}
}

int	ft_strlen (char *str)
{
	int	b;

	b = 0;
	while (str[b])
		b++;
	return (b);
}

int	check_base (char *base)
{
	int	x;
	int	y;

	x = 0;
	if (ft_strlen (base) <= 1)
		return (0);
	while (base[x])
	{
		y = x + 1;
		while (base[y])
		{
			if (base[x] == base [y] || base[y] == '-' || base[y] == '+')
				return (0);
			y++;
		}
		x++;
	}
	return (1);
}
