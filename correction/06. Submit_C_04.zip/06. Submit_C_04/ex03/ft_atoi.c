int	ft_atoi (char *str)
{
	int	minus;
	int	i;
	int	number;

	minus = 0;
	i = 0;
	number = 0;
	while (str[i] == '\t' || str[i] == '\n' || str[i] == '\v'
		   || str[i] == '\f' || str[i] == '\r' || str[i] == ' ')
		i++;
	while (str[i] == '+' || str[i] == '-')
	{
		if (str[i] == '-')
			minus++;
		i++;
	}
	while ('0' <= str[i] && str[i] <= '9')
	{
		number = number * 10 + (str[i] - '0');
		i++;
	}
	if (minus % 2 == 0)
		return (number);
	return (-number);
}
